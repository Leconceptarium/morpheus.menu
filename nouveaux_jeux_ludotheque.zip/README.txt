CONTENU DU ZIP
==============

- 21 pages HTML, toutes basées sur le style de la page Asylum.
- Un fichier ludotheque-a-ajouter.txt avec les lignes à coller dans const jeux.
- Les noms d’images attendus sont indiqués dans chaque page et dans le fichier texte.
- Le bloc vidéo YouTube est déjà présent mais commenté pour éviter une vidéo cassée.
  Quand tu as la vidéo :
  1. enlève <!-- et --> autour du bloc vidéo ;
  2. remplace ID_DE_LA_VIDEO par l’identifiant YouTube.

IMPORTANT
=========
Certaines informations (âge, durée ou nombre de joueurs) sont indiquées « À préciser »
lorsque le titre exact ou la version du jeu ne permettait pas de les confirmer sans la boîte.
Tu pourras les modifier directement dans le HTML.
